// Copyright 2017 ETH Zurich and University of Bologna.
// Copyright and related rights are licensed under the Solderpad Hardware
// License, Version 0.51 (the “License”); you may not use this file except in
// compliance with the License.  You may obtain a copy of the License at
// http://solderpad.org/licenses/SHL-0.51. Unless required by applicable law
// or agreed to in writing, software, hardware and materials distributed under
// this License is distributed on an “AS IS” BASIS, WITHOUT WARRANTIES OR
// CONDITIONS OF ANY KIND, either express or implied. See the License for the
// specific language governing permissions and limitations under the License.

/* Scheduler include files. */
#include "FreeRTOS.h"
#include "cnn.h"
#include "mnist.h"
#include "uart.h"

#define MHZ 250000
#define STD_BAUD_RATE 156250

/**
 * adjust the uart to the standard baud rate of STD_BAUD_RATE.
 * using uart0 driver from uart.h
 * void uart_set_cfg(int parity, uint16_t clk_counter);
 * Note: the default uart.c has redundant codes.
*/
void adjust_uart0_baudrate(int pll_cfg_freq_mhz)
{
    /* uint16_t clk_counter =  (pll_cfg_freq_mhz* MHZ / (16* STD_BAUD_RATE))-1;	*/
    uint16_t clk_counter = (pll_cfg_freq_mhz * MHZ / (16 * STD_BAUD_RATE));
    uart_set_cfg(0, clk_counter);
}

int main( void )
{
	adjust_uart0_baudrate(450);

	printf("Starting MNIST\n");
	printf("Reading test data\n");
	LabelArr testLabel = read_Lable_ar();
	ImgArr testImg = read_Img_ar();
	nSize inputSize={testImg->ImgPtr[0].c,testImg->ImgPtr[0].r};
	int outSize=testLabel->LabelPtr[0].l;
	printf("Test data readed\n");

	// CNN结构的初始化
	CNN s_cnn;
	CNN* cnn = &s_cnn;
	printf("Init CNN\n");
	cnnsetup(cnn,inputSize,outSize);
	printf("CNN init done\n");

	// CNN测试
	printf("Import CNN\n");
	importcnn(cnn);
	printf("CNN imported\n");
	int testNum=100;
	float incorrectRatio=0.0f;
	incorrectRatio=cnntest(cnn,testImg,testLabel,testNum);
	printf("test finished!!\n");
	printf("test incorrectRatio %d/1000 \n", (int)(incorrectRatio*1000));
	return 0;
}
