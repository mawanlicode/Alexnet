# Introduction
- Simple program to learn CNN in pure C
- Using MS VS2010 to achieve handwriting recognition
- Follow the idea of LeNet-5

# 中文说明
请参照个人系列博客【编写C语言版本的卷积神经网络CNN】

[http://blog.csdn.net/tostq/article/details/51786265](http://blog.csdn.net/tostq/article/details/51786265)
